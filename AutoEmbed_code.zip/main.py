import os
import json
import re
import subprocess
from utils.config import default_board, default_fqbn, default_port
from utils.file_utils import read_tasks_from_json, find_header_files, read_header_file_content, remove_comments, find_ino_files, read_ino_file_content
from utils.api_utils import find_best_library_for_component, download_library
from utils.gpt_processing import process_header_with_gpt4, generate_subtasks_with_gpt4, process_ino_with_gpt4, functionality_with_gpt4, validate_debug_output_with_gpt, clean_code_of_debug_info 
from utils.matching_utils import extract_functionalities, extract_subtasks, get_top_n_similarities_and_apis, match_apis
from utils.code_generation import generate_embedded_code_with_gpt4, compile_arduino_code, regenerate_embedded_code_with_feedback, install_missing_library, resolve_compilation_errors, read_serial_output


import os
import json
import re
# Assuming other necessary imports are here, e.g., from utils.file_utils import read_tasks_from_json, etc.

def main():
    # Define subfolders for organizing JSON files
    header_folder = "Header"
    example_folder = "Example"
    functionality_folder = "Functionality"
    subtask_folder = "Subtask"

    # Create the subfolders if they don't exist
    os.makedirs(header_folder, exist_ok=True)
    os.makedirs(example_folder, exist_ok=True)
    os.makedirs(functionality_folder, exist_ok=True)
    os.makedirs(subtask_folder, exist_ok=True)

    file_path = "Example_tasks.json"
    all_tasks = read_tasks_from_json(file_path)

    if not all_tasks:
        print("No tasks found in the JSON file.")
        return

    Task_number = 0
    first_task = all_tasks[Task_number]
    print(f"First task: {first_task}")
    
    pin_connections = {"DS18B20": "5"}  # Pin connections for components
    board_name, fqbn, port = default_board, default_fqbn, default_port
    task_description = first_task['task']
    
    selected_libraries = {}
    all_s_responses = {}
    component_libraries = {}
    for component_name in first_task["components"]:
        # Initialize variables to prevent accumulation
        all_h_responses = {}
        all_i_responses = {}
        all_f_responses = {}
        
        print(component_name)
        best_library = find_best_library_for_component(component_name)
        print(best_library)
        if best_library:
            selected_libraries[component_name] = best_library
            # Download the selected library
            library_name = best_library[0]['Name']
            component_libraries[component_name] = library_name
            dl = download_library(library_name)
            header_file_path = os.path.join(header_folder, f"Header_{library_name}.json")
            if os.path.exists(header_file_path):
                print(f"Header files for {library_name} already exist. Skipping...")
            else:
                # Find and print all .h files in the library
                print(library_name)
                header_files = find_header_files(library_name)
                print(f"Header files for {library_name}:")
                for header_file in header_files:
                    print(f"  {header_file}")
                    # Read the content of the .h file
                    header_content = read_header_file_content(header_file)
                    # Split content by lines
                    lines = header_content.splitlines()
                    
                    # Check if the file has more than 200 lines, then remove comments
                    if len(lines) > 200:
                        header_content = remove_comments(header_content)
                    # Process the content of the .h file
                    response = process_header_with_gpt4(header_content, os.path.basename(header_file))
                    cleaned_response = re.search(r'```json(.*?)```', response, re.DOTALL).group(1).strip()
                    # Add to the dictionary of all responses
                    all_h_responses[os.path.basename(header_file)] = json.loads(cleaned_response)
                    print(f"Response for {header_file}:\n{response}")
                with open(header_file_path, 'w', encoding='utf-8') as f:
                    json.dump(all_h_responses, f, ensure_ascii=False, indent=4)
                print(f"Responses saved to {header_file_path}")

            functionality_file_path = os.path.join(functionality_folder, f"Functionality_{library_name}.json")
            example_file_path = os.path.join(example_folder, f"Example_{library_name}.json")
            if os.path.exists(functionality_file_path) and os.path.exists(example_file_path):
                print(f"Functionality and Example files for {library_name} already exist. Skipping...")
            else:
                with open(header_file_path, 'r', encoding='utf-8') as f:
                    all_h_responses = json.load(f)
                # Find all .ino files in the library
                ino_files = find_ino_files(library_name)
                print(f"Arduino Sketch files for {library_name}:")
                all_i_responses = all_h_responses
                for ino_file in ino_files:
                    print(f"  {ino_file}")
                    # Read the content of the .ino file
                    ino_content = read_ino_file_content(ino_file)
                    # Process the content of the .ino file
                    response = process_ino_with_gpt4(ino_content, os.path.basename(ino_file), all_i_responses)
                    all_i_responses = response
                    # Process the functionality content
                    response = functionality_with_gpt4(ino_content, os.path.basename(ino_file), component_name, library_name)
                    cleaned_response = re.search(r'```json(.*?)```', response, re.DOTALL).group(1).strip()
                    # Add to the dictionary of all responses
                    all_f_responses[os.path.basename(ino_file)] = json.loads(cleaned_response)
                    print(f"Response for {ino_file}:\n{response}")
                with open(example_file_path, 'w', encoding='utf-8') as f:
                    json.dump(all_i_responses, f, ensure_ascii=False, indent=4) 
                print(f"Responses saved to {example_file_path}")
                with open(functionality_file_path, 'w', encoding='utf-8') as f:
                    json.dump(all_f_responses, f, ensure_ascii=False, indent=4)
                print(f"Responses saved to {functionality_file_path}")
        else:
            print(f"No suitable library found for component: {component_name}")

    # Print the first task and its selected libraries
    print(f"First Task for Component: {first_task['component']}")
    print(f"Description: {first_task['description']}")
    print(f"Difficulty: {first_task['difficulty']}")
    print(f"Task: {first_task['task']}")
    print("Required Components and Best Libraries:")
    for component, library in selected_libraries.items():
        print(f"  Component: {component}, Best Library: {library}")
    subtask_response = generate_subtasks_with_gpt4(first_task['task'], first_task['components'])
    cleaned_response = subtask_response.strip().strip('```json').strip('```')
    print(cleaned_response)
    all_s_responses = json.loads(cleaned_response)
    subtask_file_path = os.path.join(subtask_folder, f"Subtask_{first_task['component']}.json")
    with open(subtask_file_path, 'w', encoding='utf-8') as f:
        json.dump(all_s_responses, f, ensure_ascii=False, indent=4)
    
    # Initialize containers for aggregating functionalities of all components
    combined_etct_func = []
    combined_functionalities = {}
    combined_API_table = {}
    # Iterate through each component to collect functionality data
    for component_name in first_task["components"]:
        library_name = component_libraries.get(component_name)
        functionality_file_path = os.path.join(functionality_folder, f"Functionality_{library_name}.json")
        example_file_path = os.path.join(example_folder, f"Example_{library_name}.json")
        
        with open(functionality_file_path, 'r', encoding='utf-8') as f:
            functionalities = json.load(f)
            combined_functionalities.update(functionalities)  # Directly merge into combined_functionalities
    
            # Extract all functionality descriptions and add to the combined_etct_func list
            for func_dict in functionalities.values():
                for func_list in func_dict.values():
                    for func_item in func_list:
                        combined_etct_func.append(func_item['functionality'])
    
        with open(example_file_path, 'r', encoding='utf-8') as f:
            API_table = json.load(f)
            # Merge API_table into combined_API_table
            for header, apis in API_table.items():
                if header in combined_API_table:
                    combined_API_table[header].extend(apis)
                else:
                    combined_API_table[header] = apis
    
        etct_func_list = extract_functionalities(functionalities)  # Returns a list
        combined_etct_func.extend(etct_func_list)
        
    with open(subtask_file_path, 'r', encoding='utf-8') as f:
        subtasks = json.load(f)
    etct_subtask = extract_subtasks(subtasks)
    # Get the top two functionalities with the highest similarity for each subtask and their corresponding APIs
    top_similarities_and_apis, api_set = get_top_n_similarities_and_apis(etct_subtask, combined_etct_func, combined_functionalities)
    matched_apis = match_apis(api_set, combined_API_table)
    print(matched_apis)

    max_attempts_main = 3
    attempt_main = 0
    success_main = False
    all_libraries = [component_libraries[component_name] for component_name in first_task["components"]]
    print(all_libraries)
    validation_result = ""
    while attempt_main < max_attempts_main and not success_main:
        if attempt_main == 0:
            code = generate_embedded_code_with_gpt4(first_task["components"], board_name, pin_connections, task_description, all_libraries, matched_apis)
        else:
            code = regenerate_embedded_code_with_feedback(first_task["components"], board_name, pin_connections, task_description, all_libraries, matched_apis, validation_result, cleaned_code)
        print('CODE:', code)
        cleaned_code = code.strip().strip('```cpp').strip('```')
        # Save the generated code to a file
        sketch_path = './sketch_jul22a'
        code_file_path = os.path.join(sketch_path, 'sketch_jul22a.ino')
        
        # Ensure the directory exists
        os.makedirs(sketch_path, exist_ok=True)
        
        with open(code_file_path, 'w', encoding='utf-8') as f:
            f.write(cleaned_code)
        
        # Compile the generated code
        arduino_cli_path = 'D:\\download\\arduino-cli_1.0.4_Windows_64bit\\arduino-cli.exe'
        
        max_attempts = 5
        attempt = 0
        success = False
    
        while attempt < max_attempts and not success:
            stdout, stderr, returncode = compile_arduino_code(arduino_cli_path, sketch_path, fqbn)
    
            if returncode == 0:
                print("Compilation success:")
                print(stdout)
                success = True
            else:
                print("Compilation error:")
                print(stderr)
    
                if "fatal error" in stderr and "No such file or directory" in stderr:
                    lines = stderr.split('\n')
                    missing_library_line = next((line for line in lines if "fatal error" in line and "No such file or directory" in line), None)
                    print(missing_library_line)
                    if missing_library_line:
                        # If lines is a string, process directly
                        if isinstance(lines, str):
                            if '<' in lines and '>' in lines:
                                # Extract the library name
                                start = lines.find('<') + 1
                                end = lines.find('>')
                                missing_library = lines[start:end].strip().replace(".h", "")
                                print(f"Missing library detected: {missing_library}")
                                
                                if install_missing_library(arduino_cli_path, missing_library):
                                    print("Retrying compilation...")
                                else:
                                    print(f"Failed to install missing library: {missing_library}")
                        
                        # If lines is a list, iterate and process
                        elif isinstance(lines, list):
                            for line in lines:
                                if '<' in line and '>' in line:
                                    # Extract the library name
                                    start = line.find('<') + 1
                                    end = line.find('>')
                                    missing_library = line[start:end].strip().replace(".h", "")
                                    print(f"Missing library detected: {missing_library}")
                                    
                                    if install_missing_library(arduino_cli_path, missing_library):
                                        print("Retrying compilation...")
                                    else:
                                        print(f"Failed to install missing library: {missing_library}")
                                        break
                else:
                    resolve_compilation_errors(arduino_cli_path, sketch_path, fqbn, first_task['components'], board_name, pin_connections, first_task['task'], matched_apis, stderr)
    
            attempt += 1
    
        if success:
            upload_success = False
            attempt_upload = 0
            max_attempts_upload = 3
            while not upload_success and attempt_upload < max_attempts_upload:
                # Upload the code to the development board
                upload_command = [
                    arduino_cli_path,
                    'upload',
                    '--fqbn', fqbn,
                    '--port', port,  # Adjust based on actual conditions
                    sketch_path
                ]
                result = subprocess.run(upload_command, capture_output=True, text=True, encoding='utf-8')
                if result.returncode == 0:
                    print("Upload success:")
                    print(result.stdout)
                    upload_success = True
                else:
                    print("Upload failed:")
                    print(result.stderr)
                    attempt_upload += 1
                    continue  # Continue trying to upload
    
            # Read serial output
            output_lines = read_serial_output(port)

            # Validate the correctness of task execution
            validation_result = validate_debug_output_with_gpt(output_lines, task_description)
            print("Validation Result:", validation_result)

            if validation_result == "pass":
                # Clean the code and re-upload
                # Check the difficulty level
                if first_task['difficulty'] == 'Difficulty Level 3':
                    # Calculate task_n
                    task_n = Task_number % 5 + 1 - 2
                    # Construct the filename including task_n
                    file_name_debug = f"{first_task['component']}_{first_task['difficulty'].replace(' ', '_')}_{task_n}_debug.txt"
                else:
                    # Construct the default filename
                    file_name_debug = f"{first_task['component']}_{first_task['difficulty'].replace(' ', '_')}_debug.txt"
                # Save cleaned_code to the file
                with open(file_name_debug, 'w') as file:
                    file.write(cleaned_code)
                cleaned_code = clean_code_of_debug_info(cleaned_code)
                with open(code_file_path, 'w', encoding='utf-8') as f:
                    f.write(cleaned_code)
                upload_success = False
                attempt_upload = 0
                max_attempts_upload = 3
                while not upload_success and attempt_upload < max_attempts_upload:
                    result = subprocess.run(upload_command, capture_output=True, text=True, encoding='utf-8')
                    if result.returncode == 0:
                        print(cleaned_code)
                        print("Final code upload success:")
                        print(result.stdout)
                        # Construct the filename using component and difficulty
                        if first_task['difficulty'] == 'Difficulty Level 3':
                            # Calculate task_n
                            task_n = Task_number % 5 + 1 - 2
                            # Construct the filename including task_n
                            file_name_final = f"{first_task['component']}_{first_task['difficulty'].replace(' ', '_')}_{task_n}.txt"
                        else:
                            # Construct the default filename
                            file_name_final = f"{first_task['component']}_{first_task['difficulty'].replace(' ', '_')}.txt"
                        
                        # Save cleaned_code to the file
                        with open(file_name_final, 'w') as file:
                            file.write(cleaned_code)
                        success_main = True
                        break  # Upload successful, exit the loop
                    else:
                        attempt_upload += 1
                        print("Final code upload failed:")
                        print(result.stderr)
            else:
                # Modify the code based on feedback
                print(validation_result)  # Output feedback information
                attempt += 1  # Increase the attempt count
    
        if not success:
            print("Failed to compile the code after several attempts.")
        attempt_main = attempt_main + 1

if __name__ == "__main__":
    main()
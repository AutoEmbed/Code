# config.py
import logging

# Configuration constants
target_architecture = 'avr'
arduino_cli_path = 'D:\\download\\arduino-cli_1.0.4_Windows_64bit\\arduino-cli.exe'
libraries_dir = 'C:\\Users\\51945\\Documents\\Arduino\\libraries'
default_board = 'Arduino Uno'
default_fqbn = 'arduino:avr:uno'
default_port = 'COM6'

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
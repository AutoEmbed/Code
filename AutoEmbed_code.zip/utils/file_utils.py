import os
import json
import re
from .config import libraries_dir

def read_tasks_from_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    all_tasks = []
    for component, details in data.items():
        for difficulty, tasks in details['tasks'].items():
            for task in tasks:
                all_tasks.append({
                    "component": component,
                    "description": details["description"],
                    "difficulty": difficulty,
                    "task": task["task"],
                    "components": task["components"]
                })
    
    return all_tasks

def find_header_files(library_name):
    library_name_r = library_name.replace(" ", "_")
    library_path = os.path.join("C:\\Users\\51945\\Documents\\Arduino\\libraries", library_name_r)
    header_files = []

    for root, dirs, files in os.walk(library_path):
        for file in files:
            if file.endswith(".h"):
                header_files.append(os.path.join(root, file))
    
    return header_files

def read_header_file_content(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except UnicodeDecodeError:
        # Try an alternative encoding
        with open(file_path, 'r', encoding='ISO-8859-1') as file:
            return file.read()

def remove_comments(code):
    # Pattern to match single line comments (//) and multi-line comments (/* */)
    pattern = r"//.*?$|/\*.*?\*/"
    
    # Remove comments using re.sub
    cleaned_code = re.sub(pattern, '', code, flags=re.DOTALL | re.MULTILINE)
    
    return cleaned_code

def find_ino_files(library_name):
    library_name_r = library_name.replace(" ", "_")
    library_path = os.path.join("C:\\Users\\51945\\Documents\\Arduino\\libraries", library_name_r)
    ino_files = []

    for root, dirs, files in os.walk(library_path):
        for file in files:
            if file.endswith(".ino"):
                ino_files.append(os.path.join(root, file))
    
    return ino_files

def read_ino_file_content(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()
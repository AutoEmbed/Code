import subprocess
import os
import json
import requests
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from datetime import datetime
from .config import logger, target_architecture, arduino_cli_path, libraries_dir

def send_request_4(prompt):
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Print "Use GPT" with the current time
    print(f"Use GPT at {current_time}")
    
    # Replace with your actual OpenAI API key
    api_key = 'your_openai_api_key_here'
    
    try:
        # Use OpenAI's official API endpoint
        api_url = 'https://api.openai.com/v1/chat/completions'
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        payload = {
            'model': 'gpt-3.5-turbo',  # Use a valid OpenAI model (e.g., "gpt-3.5-turbo" or "gpt-4")
            'messages': [{'role': 'user', 'content': prompt}]
        }
        response = requests.post(api_url, headers=headers, data=json.dumps(payload))
        if response.status_code == 200:
            data = response.json()
            return data['choices'][0]['message']['content']
        else:
            return f'Error: Received status code {response.status_code} - {response.text}'
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return 'An error occurred while sending the request'
        
def search_arduino_library(library_name, n=5):
    full_search_query = f"{library_name}"
    result = subprocess.run(['D:\\download\\arduino-cli_1.0.4_Windows_64bit\\arduino-cli.exe', 'lib', 'search', full_search_query], capture_output=True, text=True, encoding='utf-8')
    
    if result.returncode != 0:
        print("Error running Arduino CLI command")
        print(result.stderr)
        return None
    
    raw_output = result.stdout
    lines = raw_output.split('\n')
    libraries = []
    current_library = {}
    
    for line in lines:
        line = line.strip()
        if not line:
            if current_library:
                libraries.append(current_library)
                current_library = {}
        elif line.startswith('Name:'):
            if current_library:
                libraries.append(current_library)
                current_library = {}
            current_library['Name'] = line[len('Name:'):].strip().strip('"')
        else:
            if ': ' in line:
                key, value = line.split(': ', 1)
                current_library[key.strip()] = value.strip()
    
    if current_library:
        libraries.append(current_library)
    
    return libraries[:n]

def get_match_score(text, component_name):
    vectorizer = TfidfVectorizer().fit_transform([text, component_name])
    vectors = vectorizer.toarray()
    return cosine_similarity(vectors)[0, 1]

def get_name_match_score(lib, component_name):
    lib_name_score = get_match_score(lib['Name'], component_name)
    lib_sentence_score = get_match_score(lib.get('Sentence', ''), component_name)
    lib_paragraph_score = get_match_score(lib.get('Paragraph', ''), component_name)
    
    total_score = (lib_name_score + 0.2*lib_sentence_score + 0.3*lib_paragraph_score) / 3
    return total_score

def get_versions_count(lib):
    versions = lib.get('Versions', '')
    if versions:
        return len(versions.split(','))
    return 0

def get_architecture_score(lib_architecture, target_architecture):
    if lib_architecture == '*':
        return 1.0
    return 1.0 if target_architecture in lib_architecture.split(',') else 0.0

def evaluate_library(lib, component_name, max_versions_count, target_architecture):
    name_match_score = get_name_match_score(lib, component_name)
    versions_count = get_versions_count(lib)
    versions_count_score = versions_count / max_versions_count if max_versions_count > 0 else 0
    architecture_score = get_architecture_score(lib.get('Architecture', ''), target_architecture)
    
    if architecture_score == 0:
        return None
    
    return {
        'name_match_score': name_match_score,
        'versions_count_score': 0.01*versions_count_score,
        'architecture_score': 0.1*architecture_score,
        'total_score': name_match_score + 0.01*versions_count_score + 0.1*architecture_score
    }


def find_best_library_for_component(component_name, top_n=5):
    libraries = search_arduino_library(component_name)
    print(libraries)
    if not libraries:
        return None
    
    libraries = [lib for lib in libraries if 'Name' in lib]
    
    if not libraries:
        return None
    
    libraries = sorted(libraries, key=lambda lib: lib['Name'])[:top_n]
    max_versions_count = max(get_versions_count(lib) for lib in libraries)
    evaluated_libraries = []
    
    for lib in libraries:
        scores = evaluate_library(lib, component_name, max_versions_count, target_architecture)
        if scores:  
            evaluated_libraries.append((lib, scores))
    
    if not evaluated_libraries:
        return None
    best_library = max(evaluated_libraries, key=lambda item: item[1]['total_score'])
    return best_library

def download_library(library_name):
    before_download = set(os.listdir("C:\\Users\\51945\\Documents\\Arduino\\libraries"))

    result = subprocess.run(['D:\\download\\arduino-cli_1.0.4_Windows_64bit\\arduino-cli.exe', 'lib', 'install', library_name], capture_output=True, text=True, encoding='utf-8')
    if result.returncode != 0:
        print(f"Error downloading library {library_name}")
        print(result.stderr)
        return None  # 返回 None 以指示下载失败
    print(f"Library {library_name} downloaded successfully.")
    
    after_download = set(os.listdir("C:\\Users\\51945\\Documents\\Arduino\\libraries"))
    
    new_folders = after_download - before_download
    if new_folders:
        actual_folder_name = new_folders.pop()
        return actual_folder_name  # 返回实际的文件夹名称
    else:
        print("No new folder detected. Library might not have been downloaded correctly.")
        return None
